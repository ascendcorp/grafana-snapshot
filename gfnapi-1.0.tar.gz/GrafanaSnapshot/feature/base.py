class Base(object):
    def __init__(self, api):
        self.api = api
