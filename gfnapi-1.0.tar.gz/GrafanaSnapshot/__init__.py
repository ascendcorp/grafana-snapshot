# -*- coding: utf-8 -*-
from .snapshot_face import SnapshotFace
